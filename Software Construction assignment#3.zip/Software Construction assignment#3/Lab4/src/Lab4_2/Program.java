/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab4_2;
import java.util.*;
import java.*;
public class Program {
    public static void main (String [] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the Name of the Shape (Circle/Rectangle/Square):");
        String Shape=input.next();
        System.out.print("Enter the Clour to fill the Shape (Red/Blue/Green):");
        String Color=input.next();
        AbstractFactory Shaper=FactoryProducer.getfactory("Shape");
        Shape s=Shaper.getshape(Shape);
        AbstractFactory Colorer=FactoryProducer.getfactory("Color");
        Color c=Colorer.getcolor(Color);
        System.out.println(s.draw().toString()+" "+c.fill().toString());
    }
    
}
