/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab4_2;

/**
 *
 * @author umerh
 */
public abstract class AbstractFactory {
    public abstract Shape getshape(String Shape);
    public abstract Color getcolor(String Color);
}
