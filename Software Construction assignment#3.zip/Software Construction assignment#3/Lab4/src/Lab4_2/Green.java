/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab4_2;
public class Green implements Color{
    @Override
    public String fill(){
        return("filled with Green.");
    }
}
