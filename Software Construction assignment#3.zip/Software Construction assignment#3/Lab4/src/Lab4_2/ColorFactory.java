/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab4_2;

/**
 *
 * @author umerh
 */
public class ColorFactory extends AbstractFactory{

    @Override
    public Color getcolor(String color){
        if(color.equalsIgnoreCase("red")){
            return new Red();
        }else if(color.equalsIgnoreCase("Blue")){
            return new Blue();
        }else if(color.equalsIgnoreCase("green")){
            return new Green();
        }else{
            return null;
        }
      
    }
    @Override
    public Shape getshape(String Shape){
        return null;
    }
}
