package findpalindrom;

import static java.time.Clock.system;
import java.util.Scanner;
public class FindPalindrom {
    
 public static void main(String[] args)
 {
 System.out.print("Enter the a five digit number: ");
 Scanner in =new Scanner(System.in);
 int num =in.nextInt();
 int n1=num/10000;
 int n2=(num%10000)/1000;
 int n3=(num%1000)/100;
 int n4=(num%100)/10;
 int n5=num%10;
 
 if(n5==n1 && n2==n4 && n3==n3)
 {
 System.out.println("This number is palindrom "+num+" same to "+""+n5+""+n4+""+n3+""+n2+""+n1);
 }
 else
 {
 System.out.println("This number is not palindrom "+num+" not same to "+""+n5+""+n4+""+n3+""+n2+""+n1);
 }
 }
    
}
