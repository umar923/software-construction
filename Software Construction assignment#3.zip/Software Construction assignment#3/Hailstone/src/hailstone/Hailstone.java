package hailstone;
public class Hailstone {
public static void main(String[] args) {
    int n=100;
    while(n != 1)
    {
    if (n%2 == 0)
    {
         int a=n/2;
         System.out.println(a);
    }else
    {
         int a=n*3+1;
         System.out.println(a);
    }
    n--;
    }    
    }
    
}
