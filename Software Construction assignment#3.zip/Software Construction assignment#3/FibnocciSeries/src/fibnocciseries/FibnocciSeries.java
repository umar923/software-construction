package fibnocciseries;
public class FibnocciSeries {
    public static void main(String[] args) {
        int fibnocci;
        int i;
        int a=0;
        int b=1;
        int c;
        for(i =1 ; i <=10;i++){
        c=a+b;
        System.out.print(" "+c);
        a=c+b;
        System.out.print(" "+a);
        b=a+c;
        System.out.print(" "+b);
        }
    } 
}
