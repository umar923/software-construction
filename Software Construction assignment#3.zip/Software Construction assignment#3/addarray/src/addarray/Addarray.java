package addarray;
class Addarray {
    public static void main(String[] args) {
        int i;
        int sum=0;
        int Myarray[]={1,5,9,11,16,3,2,2,6,7};
        for(i=0;i<10;i++){ 
            sum = sum+Myarray[i];
        }
        System.out.println("the some of array is : "+ sum );
    }
}
